# Design System Documentation

This document outlines the core visual principles and token values for our design system, ensuring consistency and a unified user experience across all products.

## Theme Overview

The design system is configured for a **light** color mode, providing a modern and comfortable viewing experience, especially in low-light environments. The overall aesthetic is balanced, utilizing a moderate roundedness for UI elements and standard spacing, aiming for clarity and ease of use.

## Color Palette

Our color palette is carefully selected to establish a distinct brand identity and enhance usability.

*   **Primary Color:** `#9c6f16` - A vibrant and commanding blue, used for primary calls to action, interactive elements, and key branding.
*   **Secondary Color:** `#8c734d` - A calm and supportive blue-gray, ideal for secondary actions, subtle highlights, and complementary elements.
*   **Tertiary Color:** `#6093cb` - A warm, earthy orange, serving as an accent for highlights, badges, or specific notifications that require attention.
*   **Neutral Color:** `#7d766d` - A versatile, understated gray, forming the foundation for backgrounds, surfaces, and non-chromatic UI components.

## Typography

Typography plays a crucial role in conveying information and establishing hierarchy. The design system utilizes a consistent font family across various text elements.

*   **Headline Font:** `Inter` - Used for all headlines and prominent textual elements, ensuring readability and impact.
*   **Body Font:** `Inter` - Applied to all standard body text, prioritizing legibility and a comfortable reading experience.
*   **Label Font:** `Inter` - Employed for labels, captions, and smaller text elements, maintaining consistency with the overall typographic style.

## Shape and Form

The visual characteristics of UI elements, including their corner treatments, are defined to create a cohesive look.

*   **Roundedness:** **2 (Moderate)** - UI elements feature moderately rounded corners, striking a balance between modern softness and clear definition. This level provides a friendly yet professional aesthetic.

## Spacing

Consistent spacing is essential for visual balance, readability, and a structured layout.

*   **Spacing:** **2 (Normal)** - The design system employs a normal level of whitespace both within and between UI elements. This provides a clean, uncluttered interface without feeling overly dense or excessively sparse.